package com.team.hogspot.model.geospot

enum class Difficulty {
    EASY,
    MEDIUM,
    HARD
}